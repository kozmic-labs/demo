module.exports = require("indexeddb")('demo', {
  version: 1
})
