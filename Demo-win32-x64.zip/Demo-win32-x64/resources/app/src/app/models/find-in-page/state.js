module.exports = get()

function get () {
  return {
    enabled: false,
    query: ''
  }
}
