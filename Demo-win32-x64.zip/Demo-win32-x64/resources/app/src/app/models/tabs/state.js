const Tab = require("./tab")

module.exports = get();

function get (callback) {
  return {}
}
