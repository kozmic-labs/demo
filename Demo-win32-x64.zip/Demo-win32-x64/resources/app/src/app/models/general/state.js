module.exports = get()

function get () {
  return {
    focusMode: false,
    privateMode: false,
    partitionName: 'persist:demo'
  }
}
