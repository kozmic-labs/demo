module.exports = get();

function get () {
  return {
    isOpen: false,
    preview: null,
    query: '',
    results: []
  }
}
