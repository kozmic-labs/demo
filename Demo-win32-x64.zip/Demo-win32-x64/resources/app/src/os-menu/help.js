module.exports = help

function help () {
  return {
    label: 'Help',
    role: 'help',
    submenu: [
      {
        label: 'Keyboard Shortcuts',
        click: function () {
        }
      },
      {
        label: 'Report a Bug',
        click: function () {
        }
      },
      {
        label: 'Take a Tour',
        click: function () {
        }
      },
      {
        label: 'View on GitHub',
        click: function () {
        }
      }
    ]
  }
}
