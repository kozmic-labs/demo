const WindowManager = require("./src/window-manager")
const { app } = require("electron")
var mainWindow = new WindowManager(app);
